# Space Shooter Game

# Team members
 * Lokith N
 * Manoj M
 * Sai krishnar M


## Topic
15 - Space Shooter

## Description
A browser-based Space Shooter game where the player controls a spaceship
to shoot incoming enemies and avoid collisions.

## How to Play
- Click Start Game
- Use Arrow Keys to move
- Press Spacebar to shoot enemies
- Avoid enemy collisions

## Technologies Used
- HTML
- CSS
- JavaScript

## Features
- Start Screen
- Gameplay Screen
- Game Over Screen
- Score System

## GitHub Repository
(Add your GitHub link here)
