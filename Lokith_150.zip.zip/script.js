const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let player, bullets, enemies, score, gameLoop;
let keys = {};

document.addEventListener("keydown", e => keys[e.code] = true);
document.addEventListener("keyup", e => keys[e.code] = false);

function startGame() {
  document.getElementById("startScreen").classList.add("hidden");
  document.getElementById("gameScreen").classList.remove("hidden");
  initGame();
}

function initGame() {
  player = { x: 180, y: 440, width: 40, height: 40 };
  bullets = [];
  enemies = [];
  score = 0;
  document.getElementById("score").innerText = "Score: 0";
  gameLoop = setInterval(updateGame, 50);
}

function updateGame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  movePlayer();
  drawPlayer();
  moveBullets();
  moveEnemies();
  detectCollisions();

  if (Math.random() < 0.03) {
    enemies.push({ x: Math.random() * 360, y: 0, size: 30 });
  }
}

function movePlayer() {
  if (keys["ArrowLeft"] && player.x > 0) player.x -= 5;
  if (keys["ArrowRight"] && player.x < 360) player.x += 5;
  if (keys["Space"]) shoot();
}

function drawPlayer() {
  ctx.fillStyle = "cyan";
  ctx.fillRect(player.x, player.y, player.width, player.height);
}

function shoot() {
  if (bullets.length === 0 || bullets[bullets.length - 1].y < player.y - 20) {
    bullets.push({ x: player.x + 18, y: player.y });
  }
}

function moveBullets() {
  ctx.fillStyle = "yellow";
  bullets.forEach((b, i) => {
    b.y -= 8;
    ctx.fillRect(b.x, b.y, 4, 10);
    if (b.y < 0) bullets.splice(i, 1);
  });
}

function moveEnemies() {
  ctx.fillStyle = "red";
  enemies.forEach((e, i) => {
    e.y += 4;
    ctx.fillRect(e.x, e.y, e.size, e.size);
    if (e.y > canvas.height) endGame();
  });
}

function detectCollisions() {
  enemies.forEach((e, ei) => {
    bullets.forEach((b, bi) => {
      if (
        b.x < e.x + e.size &&
        b.x + 4 > e.x &&
        b.y < e.y + e.size &&
        b.y + 10 > e.y
      ) {
        enemies.splice(ei, 1);
        bullets.splice(bi, 1);
        score++;
        document.getElementById("score").innerText = "Score: " + score;
      }
    });

    if (
      player.x < e.x + e.size &&
      player.x + player.width > e.x &&
      player.y < e.y + e.size &&
      player.y + player.height > e.y
    ) {
      endGame();
    }
  });
}

function endGame() {
  clearInterval(gameLoop);
  document.getElementById("gameScreen").classList.add("hidden");
  document.getElementById("gameOverScreen").classList.remove("hidden");
  document.getElementById("finalScore").innerText = "Final Score: " + score;
}

function restartGame() {
  document.getElementById("gameOverScreen").classList.add("hidden");
  document.getElementById("startScreen").classList.remove("hidden");
}
